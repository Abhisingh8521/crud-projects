// import 'package:flutter/material.dart';
//
// class AddCostumerScreens extends StatefulWidget {
//   const AddCostumerScreens({super.key});
//
//   @override
//   State<AddCostumerScreens> createState() => _AddCostumerScreensState();
// }
//
// class _AddCostumerScreensState extends State<AddCostumerScreens> {
//   var _formKey = GlobalKey<FormState>();
//   @override
//   Widget build(BuildContext context) {
//     var view = UserTextfield();
//     return  Scaffold(
//       appBar: AppBar(
//         title: const Text('Add Data'),
//         centerTitle: true,
//       ),
//       body: SingleChildScrollView(
//         child: Form(
//           key:  _formKey,
//           child: Column(
//             children: [
//
//             ],
//
//           ),
//         ),
//       )
//     );
//   }
// }
