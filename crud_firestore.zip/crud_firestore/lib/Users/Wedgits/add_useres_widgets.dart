import 'package:flutter/material.dart';

class UiHelper {
  late BuildContext context;

  static UserTextfield(
      TextEditingController controller, String text, Icon icon) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
            border: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(10))),
            hintText: text,
            prefixIcon: icon),
        validator: (String? text) {
          if (text!.isEmpty) {
            return "this is required";
          } else {
            return null;
          }
        },
      ),
    );
  }

  Widget checkBoxView(bool value, {required void Function(bool?)? onChanged}) =>
      CheckboxListTile(
        value: value,
        onChanged: onChanged,
        title: const Text("Is Married"),
      );
}
