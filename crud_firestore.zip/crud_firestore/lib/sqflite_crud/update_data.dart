import 'package:crud_firestore/sqflite_crud/widgits.dart';
import 'package:flutter/material.dart';
import 'database_handler.dart'; // Import your database handler here
import 'model.dart'; // Import your DataModel here
import 'read_data.dart'; // Import FetchData widget or the relevant page

class UserDetails extends StatefulWidget {
  final DataModel userData;

  UserDetails({
    required this.userData,
  });

  @override
  _UserDetailsState createState() => _UserDetailsState();
}

class _UserDetailsState extends State<UserDetails> {
  var database = DBHelper();

  late TextEditingController nameController;
  late TextEditingController addressController;

  @override
  void initState() {
    super.initState();
    database;
    nameController = TextEditingController(text: widget.userData.name);
    addressController = TextEditingController(text: widget.userData.address);
  }

  @override
  void dispose() {
    nameController.dispose();
    addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var view = AddCustomer(context: context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Data'),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            view.fieldView(nameController, "Enter your Title"),
            SizedBox(
              height: 20,
            ),
            view.fieldView(addressController, "Enter your Description"),
            ElevatedButton(
              onPressed: () async {
                DataModel updatedData = DataModel(
                  id: widget.userData.id,
                  name: nameController.text.toString(),
                  address: addressController.text.toString(),
                  currentDate: widget.userData.currentDate,
                  updatedTime: DateTime.now().toString(),
                );

                await database.updateData(updatedData);

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Changes saved')),
                );

                Navigator.pop(context);
              },
              child: const Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }
}
