import 'dart:convert';

DataModel dataModelFromJson(String str) => DataModel.fromMap(json.decode(str));

String dataModelToJson(DataModel data) => json.encode(data.toJson());

class DataModel {
  int? id;
  String name;
  String address;
  String? currentDate;
  String? updatedTime;

  DataModel({
    this.id,
    required this.name,
    required this.address,
    this.currentDate,
    this.updatedTime,
  });

  factory DataModel.fromMap(Map<String, dynamic> json) {
    return DataModel(
      id: json['id'] as int?,
      name: json['name'] ?? '',
      address: json['address'] ?? '',
      currentDate: json['currentDate'] as String?,
      updatedTime: json['updatedTime'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "name": name,
      "address": address,
      "currentDate": currentDate,
      "updatedTime": updatedTime,
    };
  }
}
//margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),