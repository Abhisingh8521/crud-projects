import 'package:crud_firestore/sqflite_crud/widgits.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'database_handler.dart';
import 'model.dart';

class AddData extends StatefulWidget {
  const AddData({Key? key}) : super(key: key);

  @override
  _AddDataFirestoreState createState() => _AddDataFirestoreState();
}

class _AddDataFirestoreState extends State<AddData> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late DBHelper dbHelper;

  @override
  void initState() {
    super.initState();
    dbHelper = DBHelper();
  }

  @override
  Widget build(BuildContext context) {
    var view = AddCustomer(context: context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Data'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: 50),
                view.fieldView(_firstNameController, "Enter your title"),
                SizedBox(height: 20),
                view.fieldView(_addressController, " Enter your Description"),
                SizedBox(height: 60),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      dbHelper.insertData(DataModel(
                        name: _firstNameController.text,
                        address: _addressController.text,
                      ));
                      Navigator.pop(context);

                      Fluttertoast.showToast(
                        msg: 'Data added successfully',
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: Colors.deepPurple,
                        textColor: Colors.white,
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    elevation: 4 , backgroundColor: Colors.blue,
                  ),
                  child: const Text(
                    'Submit Data',
                    style: TextStyle(color: Colors.white, letterSpacing: 2),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
