// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'Read_Data.dart';
// import 'main.dart';
//
//
// class UpdateUserData extends StatefulWidget {
//   final UserData userData;
//
//   const UpdateUserData({Key? key, required this.userData}) : super(key: key);
//   @override
//   _UpdateUserDataState createState() => _UpdateUserDataState();
// }
//
// class _UpdateUserDataState extends State<UpdateUserData> {
//   late TextEditingController _firstNameController;
//   late TextEditingController _lastNameController;
//   late TextEditingController _phoneController;
//   late TextEditingController _ageController;
//   late bool _isMarried;
//
//   @override
//   void initState() {
//     super.initState();
//     _firstNameController =
//         TextEditingController(text: widget.userData.firstName);
//     _lastNameController = TextEditingController(text: widget.userData.lastName);
//     _phoneController =
//         TextEditingController(text: widget.userData.phone.toString());
//     _ageController =
//         TextEditingController(text: widget.userData.age.toString());
//     _isMarried = widget.userData.isMarried;
//   }
//
//   @override
//   void dispose() {
//     _firstNameController.dispose();
//     _lastNameController.dispose();
//     _phoneController.dispose();
//     _ageController.dispose();
//     super.dispose();
//   }
//
//   Future<void> _updateUserData() async {
//     try {
//       String firstName = _firstNameController.text;
//       String lastName = _lastNameController.text;
//       double phone = double.parse(_phoneController.text);
//       int age = int.parse(_ageController.text);
//
//       await FirebaseFirestore.instance
//           .collection('users_data')
//           .doc(widget.userData.id)
//           .update({
//         'first_name': firstName,
//         'last_name': lastName,
//         // 'phone': phone,
//         // 'age': age,
//         // 'is_married': _isMarried,
//       });
//       Fluttertoast.showToast(
//         msg: 'Update Successful',
//         toastLength: Toast.LENGTH_SHORT,
//         gravity: ToastGravity.BOTTOM,
//       );
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (context) => const MyHomePage()),
//       );
//     }
//     catch (e) {
//       Fluttertoast.showToast(
//         msg: 'Failed',
//         toastLength: Toast.LENGTH_SHORT,
//         gravity: ToastGravity.BOTTOM,
//       );
//       print('Error updating data: $e');
//       // Handle error if needed
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Update Data'),
//         centerTitle: true,
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(19.0),
//           child: Column(
//             children: [
//               SizedBox(height: 50,),
//               TextFormField(
//                 controller: _firstNameController,
//                 decoration: const InputDecoration(
//                   labelText: 'First Name',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.zero,
//                   ),
//                 ),
//               ),
//               SizedBox(height: 20),
//               TextFormField(
//                 controller: _lastNameController,
//                 decoration: const InputDecoration(
//                   labelText: 'Last Name',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.zero,
//                   ),
//                 ),
//               ),
//               SizedBox(height: 20),
//               TextFormField(
//                 controller: _phoneController,
//                 keyboardType: TextInputType.phone,
//                 decoration: const InputDecoration(
//                   labelText: 'Phone',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.zero,
//                   ),
//                 ),
//               ),
//               SizedBox(height: 20),
//               TextFormField(
//                 controller: _ageController,
//                 keyboardType: TextInputType.number,
//                 decoration: const InputDecoration(
//                   labelText: 'Age',
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.zero,
//                   ),
//                 ),
//               ),
//               Row(
//                 children: [
//                   Checkbox(
//                     value: _isMarried,
//                     onChanged: (value) {
//                       setState(() {
//                         _isMarried = value ?? false;
//                       });
//                     },
//                   ),
//                   const Text('Is Married'),
//                 ],
//               ),
//               ElevatedButton(
//                 onPressed: _updateUserData,
//                 child: const Text('Update'),
//               ),
//             ],
//           ),
//         ),
//       ),
//
//     );
//   }
// }
