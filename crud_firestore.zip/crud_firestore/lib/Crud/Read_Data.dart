import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'Update_Data.dart';

class UserData {
  final String id;
  final String firstName;
  final String lastName;
  final double phone;
  final int age;
  final bool isMarried;
  UserData({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.phone,
    required this.age,
    required this.isMarried,
  });
}
class FetchDataFirestore extends StatefulWidget {
  const FetchDataFirestore({Key? key}) : super(key: key);

  @override
  _FetchDataFirestoreState createState() => _FetchDataFirestoreState();
}
class _FetchDataFirestoreState extends State<FetchDataFirestore> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<UserData>> fetchData() async {
    QuerySnapshot querySnapshot =
        await _firestore.collection('users_data').get();
    List<UserData> userDataList = querySnapshot.docs.map((doc) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      return UserData(
        id: doc.id,
        firstName: data['first_name'] ?? '',
        lastName: data['last_name'] ?? '',
        phone: data['phone'] ?? '',
        age: data['age'] ?? '',
        isMarried: data['is_married'] ?? false,
      );
    }).toList();
    return userDataList;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: fetchData(),
        builder: (context, AsyncSnapshot<List<UserData>> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No data'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                UserData userData = snapshot.data![index];
                return ListTile(
                  textColor: Colors.redAccent,
                  subtitleTextStyle: const TextStyle(color: Colors.blue),
                  title: Text('${userData.firstName} ${userData.lastName}'),
                  subtitle: Text(
                    style: const TextStyle(color: Colors.blue),
                      'Phone:  ${userData.phone} \nAge:  ${userData.age} \nGender :  ${userData.isMarried}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) =>
                      //         UpdateUserData(userData: userData),
                      //   ),
                      // );
                    },
                  ),

                );
              },

            );
          }
        },
      ),
    );
  }
}
