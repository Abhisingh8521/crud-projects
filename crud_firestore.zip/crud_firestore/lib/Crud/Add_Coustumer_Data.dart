import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class AddUserData extends StatefulWidget {
  const AddUserData({Key? key}) : super(key: key);

  @override
  State<AddUserData> createState() => _AddUserDataState();
}

class _AddUserDataState extends State<AddUserData> {
  final formKey = GlobalKey<FormState>();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final firebase = FirebaseFirestore.instance;


  Future<void> AddUserData() async {
    if (!formKey.currentState!.validate()) {
      return;
    }
    try {
      Map<String, dynamic> data = {
        "id": firebase.collection("userData").doc().id,
        "name": _firstNameController.text,
        "address": _addressController.text,
        "email": _emailController.text,
        "phone": _phoneController.text
      };
      await firebase.collection("userData").doc().set(data);
      Fluttertoast.showToast(
          msg: "Add Data SuccessFull",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.blue);
    } catch (w) {
      Fluttertoast.showToast(
          msg: "Add Data Field$w",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
            child: Column(
              children: [
                SizedBox(height: 50),
                _buildFirstNameField(_firstNameController, 'Name'),
                SizedBox(height: 20),
                _buildFirstNameField(_addressController, 'Address'),
                SizedBox(height: 20),
                _buildFirstNameField(_emailController, "Email"),
                SizedBox(height: 20),
                _buildFirstNameField(_phoneController, 'Phone'),
                SizedBox(height: 20),
                ElevatedButton(
                    onPressed: () {
                      AddUserData();
                    },
                    child: const Text("Submit"))

              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFirstNameField(TextEditingController controller, String hint) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        border: const OutlineInputBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(15.0),
          ),
        ),
        filled: true,
        hintStyle: TextStyle(color: Colors.blueAccent),
        fillColor: Colors.white,
        hintText: hint,
      ),
      validator: (value) {
        if (value!.isEmpty) {
          return "This field is required";
        }
        return null;
      },
    );
  }
}
