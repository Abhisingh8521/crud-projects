import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:crud_firestore/customers/customers/widgets/show_customer_widgets.dart';
import 'package:flutter/material.dart';

import 'add_customer_screen.dart';
import 'controllers/customer_controller.dart';
import 'models/customer_data_model.dart';


class ShowCustomersScreen extends StatefulWidget {
  const ShowCustomersScreen({super.key});

  @override
  State<ShowCustomersScreen> createState() => _ShowCustomersScreenState();
}

class _ShowCustomersScreenState extends State<ShowCustomersScreen> {
  @override
  Widget build(BuildContext context) {
    var view = ShowCustomerWidgets(context: context);
    var controller = CustomerController();
    return Scaffold(
        floatingActionButton: view.flotButtonView(onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (c) => AddCustomerScreen(
                        data: CustomerDataModel(),
                        isUpdate: false,
                      )));
        }),
        body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: controller.getCustomers(),
            builder: (c, snap) {
              var data = snap.data?.docs
                  .map((e) => CustomerDataModel.fromJson(e.data()))
                  .toList();
              if (snap.hasData) {
                return ListView.builder(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 20),
                    itemCount: data?.length ?? 0,
                    itemBuilder: (c, i) {
                      return view.itemView(data![i], onUpdate: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (c) => AddCustomerScreen(
                                      data: data[i],
                                      isUpdate: true,
                                    )));
                      }, onDelete: () {
                        controller.deleteCustomer(data[i].docId ?? "");
                      });
                    });
              } else {
                return const CircularProgressIndicator();
              }
            }));
  }

  showMenuItems(BuildContext context) {
    var view = ShowCustomerWidgets(context: context);
    return showMenu(
        context: context,
        position: RelativeRect.fill,
        items: [view.menuItemView("Update"), view.menuItemView("Delete")]);
  }
}
