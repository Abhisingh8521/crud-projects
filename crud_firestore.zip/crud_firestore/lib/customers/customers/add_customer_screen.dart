import 'package:crud_firestore/customers/customers/widgets/add_customer_widgets.dart';
import 'package:flutter/material.dart';
import 'controllers/customer_controller.dart';
import 'models/customer_data_model.dart';


class AddCustomerScreen extends StatefulWidget {
  final CustomerDataModel data;
  final bool isUpdate;
  const AddCustomerScreen({super.key,required this.data,required this.isUpdate});

  @override
  State<AddCustomerScreen> createState() => _AddCustomerScreenState();
}

class _AddCustomerScreenState extends State<AddCustomerScreen> {
  bool isSelected = false;
  TextEditingController firstNameCon = TextEditingController();
  TextEditingController lastNameCon = TextEditingController();
  TextEditingController phoneCon = TextEditingController();
  TextEditingController ageCon = TextEditingController();

  var _customerKey = GlobalKey<FormState>();

  @override
  void initState() {
    firstNameCon = TextEditingController(text:widget.data.firstName );
    lastNameCon = TextEditingController(text: widget.data.lastName);
    phoneCon = TextEditingController(text: widget.data.phone == null?"":widget.data.phone.toString());
    ageCon = TextEditingController(text: widget.data.age == null?"":widget.data.age.toString());
    isSelected = widget.data.isMarried??false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var view = AddCustomerWidgets(context: context);
    return Scaffold(
      body: Form(
        key: _customerKey,
          child: ListView(
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 40),
        children: [
          view.fieldView(firstNameCon, "First name ", Icon(Icons.people)),
          SizedBox(
            height: 10,
          ),
          view.fieldView(lastNameCon,"Last name ", Icon(Icons.person)),
          SizedBox(
            height: 10,
          ),
          view.fieldView(phoneCon,"Phone", Icon(Icons.phone_android)),
          SizedBox(
            height: 10,
          ),
          view.fieldView(ageCon,"Age", Icon(Icons.numbers)),
          SizedBox(
            height: 20,
          ),
          view.checkBoxView(isSelected, onChanged: (value) {
            setState(() {
              isSelected = !isSelected;
            });
          }),
          SizedBox(
            height: 40,
          ),
          widget.isUpdate == true?view.addButtonView("Update",onPressed: ()async {
            if(_customerKey.currentState!.validate()){
              var controller = CustomerController();
              var data = CustomerDataModel(
                  firstName: firstNameCon.text,
                  lastName: lastNameCon.text,
                  phone: num.parse(phoneCon.text),
                  age: double.parse(ageCon.text),
                  docId: widget.data.docId??"",
                  isMarried: isSelected);
              await controller.updateCustomer(data);
              Navigator.pop(context);

            }
          }):view.addButtonView("Add",onPressed: () {
            if(_customerKey.currentState!.validate()){
              addCustomer();
              Navigator.pop(context);
            }
          }),
        ],
      )),
    );
  }

  addCustomer()async {
    var controller = CustomerController();
    var data = CustomerDataModel(
        firstName: firstNameCon.text,
        lastName: lastNameCon.text,
        phone: num.parse(phoneCon.text),
        age: double.parse(ageCon.text),
        isMarried: isSelected);
    var response =await controller.addCustomer(data);
    if (response) {
      ScaffoldMessenger.of  (context).showSnackBar(SnackBar(
        content: Text("Customer added successfully"),
        backgroundColor: Colors.green,
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Customer not added successfully"),
        backgroundColor: Colors.red,
      ));
    }
  }
}
