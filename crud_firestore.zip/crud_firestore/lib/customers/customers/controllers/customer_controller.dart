import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer_data_model.dart';

class CustomerController {
  var fireStore = FirebaseFirestore.instance;

  Future<bool> addCustomer(CustomerDataModel dataModel) async {
    var res = false;
    await fireStore.collection("customers").add(dataModel.toJson()).then((value)async {
      var id = value.id;
      await fireStore.collection("customers").doc(id).update({"doc_id":id});
      res = true;
    });
    return res;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getCustomers() {
    return fireStore.collection("customers").snapshots();
  }

 Future<void> deleteCustomer(String docId)async{
    await fireStore.collection("customers").doc(docId).delete();
  }

  Future<void> updateCustomer(CustomerDataModel data)async{
    await fireStore.collection("customers").doc(data.docId).update(data.toJson());
  }
}
