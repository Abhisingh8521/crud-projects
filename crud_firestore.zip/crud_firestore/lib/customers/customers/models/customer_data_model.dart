// To parse this JSON data, do
//
//     final customerDataModel = customerDataModelFromJson(jsonString);

import 'dart:convert';

CustomerDataModel customerDataModelFromJson(String str) => CustomerDataModel.fromJson(json.decode(str));

String customerDataModelToJson(CustomerDataModel data) => json.encode(data.toJson());

class CustomerDataModel {
  String? firstName;
  String? lastName;
  num? phone;
  double? age;
  bool? isMarried;
  String? docId;

  CustomerDataModel({
    this.firstName,
    this.lastName,
    this.phone,
    this.age,
    this.isMarried,
    this.docId
  });


  factory CustomerDataModel.fromJson(Map<String, dynamic> json) => CustomerDataModel(
    firstName: json["first_name"],
    lastName: json["last_name"],
    phone: json["phone"],
    age: json["age"],
    isMarried: json["is_married"],
    docId: json['doc_id']
  );

  Map<String, dynamic> toJson() => {
    "first_name": firstName,
    "last_name": lastName,
    "phone": phone,
    "age": age,
    "is_married": isMarried,
    "doc_id":docId
  };

}
