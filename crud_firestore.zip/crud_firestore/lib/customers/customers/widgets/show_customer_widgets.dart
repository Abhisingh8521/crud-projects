  import 'package:flutter/material.dart';

  import '../models/customer_data_model.dart';

  class ShowCustomerWidgets {
    BuildContext context;

    ShowCustomerWidgets({required this.context});

    Widget itemView(CustomerDataModel data,
            {required void Function()? onUpdate,
            required void Function()? onDelete}) =>
        Card(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _textView("First Name", data.firstName ?? ""),
                    PopupMenuButton(
                      icon: Icon(Icons.more_vert),
                      itemBuilder: (BuildContext context) {
                        return [
                          menuItemView("Update", onTap: onUpdate),
                          menuItemView("Delete", onTap: onDelete)
                        ];
                      },
                    )
                  ],
                ),
                _textView("Last Name", data.lastName ?? ""),
                _textView("Phone no", data.phone.toString() ?? ""),
                _textView("Age", data.age.toString()),
                _textView("Marital Status",
                    data.isMarried == true ? "Married" : "Unmarried"),
              ],
            ),
          ),
        );

    Widget _textView(String title, String value) => Row(
          children: [
            Text(
              title,
              style: TextStyle(fontWeight: FontWeight.w300),
            ),
            const SizedBox(
              width: 10,
            ),
            Text(
              value,
              style: TextStyle(fontWeight: FontWeight.normal),
            ),
          ],
        );

    Widget flotButtonView({required void Function()? onPressed}) =>
        FloatingActionButton(
          onPressed: onPressed,
          child: Icon(Icons.add),
        );

    PopupMenuEntry menuItemView(String title, {void Function()? onTap}) =>
        PopupMenuItem(onTap: onTap, child: Text(title));
  }
