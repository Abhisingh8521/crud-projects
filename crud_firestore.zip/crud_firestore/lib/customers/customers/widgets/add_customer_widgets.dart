import 'package:flutter/material.dart';

class AddCustomerWidgets {
  BuildContext context;

  AddCustomerWidgets({required this.context});

  Widget fieldView(TextEditingController controller, String text, Icon icon) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
          border: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(10))),
          hintText: text,
          prefixIcon: icon),
      validator: (String? text) {
        if (text!.isEmpty) {
          return "This is required!";
        } else {
          return null;
        }
      },
    );
  }

  Widget checkBoxView(bool value, {required void Function(bool?)? onChanged}) =>
      CheckboxListTile(
        value: value,
        onChanged: onChanged,
        title: Text("Is Married"),
      );

  Widget addButtonView(String title, {required void Function()? onPressed}) =>
      ElevatedButton(onPressed: onPressed, child: Text(title));
}
