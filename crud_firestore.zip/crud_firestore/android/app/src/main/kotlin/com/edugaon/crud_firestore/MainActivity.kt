package com.edugaon.crud_firestore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
